#include "helicopter_control.h"
#include "esc_control.h"
#include <math.h>

static float clamp_f(float x, float lo, float hi)
{
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static float pitch_pot_to_deg(uint16_t adc_raw)
{
  uint16_t adc = adc_raw;

  if (adc < PITCH_ADC_LOW_RAW)  adc = PITCH_ADC_LOW_RAW;
  if (adc > PITCH_ADC_HIGH_RAW) adc = PITCH_ADC_HIGH_RAW;

  float n;
  if (adc >= PITCH_ADC_CENTER_RAW) {
    uint32_t span = (uint32_t)(PITCH_ADC_HIGH_RAW - PITCH_ADC_CENTER_RAW);
    if (span < 1u) span = 1u;
    n = (float)((int32_t)adc - (int32_t)PITCH_ADC_CENTER_RAW) / (float)span;
  } else {
    uint32_t span = (uint32_t)(PITCH_ADC_CENTER_RAW - PITCH_ADC_LOW_RAW);
    if (span < 1u) span = 1u;
    n = (float)((int32_t)adc - (int32_t)PITCH_ADC_CENTER_RAW) / (float)span;
  }

  n = clamp_f(n, -1.0f, 1.0f);
  return n * PITCH_MAX_DEG;
}

static float yaw_pot_to_deg(const HelicopterControl *control, uint16_t adc_raw)
{
  uint16_t adc = adc_raw;

  if (adc < (uint16_t)YAW_POT_LOW_ADC)  adc = (uint16_t)YAW_POT_LOW_ADC;
  if (adc > (uint16_t)YAW_POT_HIGH_ADC) adc = (uint16_t)YAW_POT_HIGH_ADC;

  float n;
  if (adc >= (uint16_t)control->yaw_mid_adc) {
    uint32_t span = (uint32_t)((uint16_t)YAW_POT_HIGH_ADC - (uint16_t)control->yaw_mid_adc);
    if (span < 1u) span = 1u;
    n = (float)((int32_t)adc - (int32_t)control->yaw_mid_adc) / (float)span;
  } else {
    uint32_t span = (uint32_t)((uint16_t)control->yaw_mid_adc - (uint16_t)YAW_POT_LOW_ADC);
    if (span < 1u) span = 1u;
    n = (float)((int32_t)adc - (int32_t)control->yaw_mid_adc) / (float)span;
  }

  n = clamp_f(n, -1.0f, 1.0f);
  return n * YAW_MAX_DEG;
}

void HelicopterControl_Init(HelicopterControl *control)
{
  *control = (HelicopterControl){0};
  control->yaw_mid_adc = YAW_POT_MID_ADC;
}

void HelicopterControl_Enable(HelicopterControl *control, uint16_t yaw_adc)
{
  control->yaw_mid_adc = (int32_t)yaw_adc;
  control->pitch_i_us = 0.0f;
  control->yaw_i_us = 0.0f;
  control->yaw_prev_err = 0;
  control->yaw_kick_until = 0;
}

void HelicopterControl_UpdateFeedback(HelicopterControl *control,
uint16_t yaw_adc, uint16_t pitch_adc)
{
  control->yaw_deg = yaw_pot_to_deg(control, yaw_adc);
  control->pitch_deg = pitch_pot_to_deg(pitch_adc);
}

HelicopterYawCommand HelicopterControl_UpdateYaw(HelicopterControl *control,
uint16_t yaw_adc, uint32_t now_ms, float delta_min_us, float delta_max_us)
{
  HelicopterYawCommand command = {0.0f, 1u, 0u};
  /* Preserve legacy goto: 7..25 counts skips D, kick, slew AND PWM write.
     The 0..6-count hard-neutral branch still writes immediately. */
  int32_t yaw_err = (int32_t)control->yaw_mid_adc - (int32_t)yaw_adc;
  int32_t ae = (yaw_err >= 0) ? yaw_err : -yaw_err;

  if (ae <= (int32_t)YAW_ADC_DB_COUNTS)
  {
    control->yaw_i_us = 0.0f;
    control->yaw_prev_err = 0;
    control->yaw_kick_until = 0;

    command.hard_neutral = 1u;
    return command;
  }
  else
  {

    float yaw_p = (float)yaw_err * YAW_KP_US_PER_COUNT;

    if (ae <= (int32_t)YAW_I_FREEZE_COUNTS)
    {

      command.update_pwm = 0u;
      return command;
    }

    /* Near/far integral scheduling, with leak only in the far region. */
    float i_limit = (ae <= YAW_I_ENABLE_COUNTS) ? YAW_I_LIMIT_NEAR_US : YAW_I_LIMIT_FAR_US;
    float ki_mult = (ae <= YAW_I_ENABLE_COUNTS) ? YAW_KI_NEAR_MULT : YAW_KI_FAR_MULT;
    float yaw_di  = (YAW_KI_US_PER_COUNT_S * ki_mult * (float)yaw_err) * DT_S;

    float yaw_i_new = control->yaw_i_us + yaw_di;

    if (ae > YAW_I_ENABLE_COUNTS) yaw_i_new *= YAW_I_LEAK_FAR;

    yaw_i_new = clamp_f(yaw_i_new, -i_limit, +i_limit);

    /* Reject integration that pushes farther into the ramp saturation. */
    float yaw_delta_tmp = (yaw_p + yaw_i_new) * YAW_CONTROL_SIGN;
    if ((yaw_delta_tmp >= delta_max_us && yaw_err > 0) ||
        (yaw_delta_tmp <= delta_min_us && yaw_err < 0))
    {
      yaw_i_new = control->yaw_i_us;
    }
    control->yaw_i_us = yaw_i_new;

    /* Keep derivative history even though the preserved Kd is zero. */
    float yaw_d = (float)(yaw_err - control->yaw_prev_err) / DT_S;
    float yaw_d_us = YAW_KD_US_S_PER_COUNT * yaw_d;
    control->yaw_prev_err = yaw_err;

    float yaw_delta = (yaw_p + control->yaw_i_us + yaw_d_us) * YAW_CONTROL_SIGN;

    if (ae >= (int32_t)YAW_MIN_DELTA_ERR_CNT)
    {
      float ad = fabsf(yaw_delta);
      if (ad < YAW_MIN_DELTA_US) {
        yaw_delta = (yaw_delta >= 0.0f) ? YAW_MIN_DELTA_US : -YAW_MIN_DELTA_US;
      }
    }

    if (ae <= (int32_t)YAW_KICK_AE_COUNTS)
    {
      if (control->yaw_kick_until < now_ms) {
        control->yaw_kick_until = now_ms + (uint32_t)YAW_KICK_MS;
      }
    }
    if (now_ms < control->yaw_kick_until)
    {
      if (yaw_delta > 0.0f) yaw_delta = fmaxf(yaw_delta,  (float)YAW_KICK_MIN_DELTA_US);
      else                  yaw_delta = fminf(yaw_delta, -(float)YAW_KICK_MIN_DELTA_US);
    }

    yaw_delta = clamp_f(yaw_delta, delta_min_us, delta_max_us);

    command.delta_us = yaw_delta;
    return command;
  }
}

float HelicopterControl_UpdatePitch(HelicopterControl *control, float max_us)
{
  /* Preserve saturation before integral rollback; ESC rounds the result. */
  float pitch_err = 0.0f - control->pitch_deg;
  if (fabsf(pitch_err) < PITCH_DEADBAND_DEG) pitch_err = 0.0f;

  float pitch_p2 = PITCH_P_GAIN_US_PER_DEG * pitch_err;

  float di = (PITCH_I_GAIN_US_PER_DEG_S * pitch_err) * DT_S;
  control->pitch_i_us += di;
  control->pitch_i_us  = clamp_f(control->pitch_i_us, -PITCH_I_LIMIT_US, +PITCH_I_LIMIT_US);

  float pitch_u = (float)PITCH_HOVER_US_INIT + PITCH_CONTROL_SIGN * (pitch_p2 + control->pitch_i_us);
  float pitch_sat = clamp_f(pitch_u, (float)PITCH_CTRL_MIN_US, max_us);

  if ((pitch_u > max_us && pitch_err > 0.0f) ||
      (pitch_u < (float)PITCH_CTRL_MIN_US && pitch_err < 0.0f))
  {
    control->pitch_i_us -= di;
    control->pitch_i_us = clamp_f(control->pitch_i_us, -PITCH_I_LIMIT_US, +PITCH_I_LIMIT_US);
  }
  return pitch_sat;
}
