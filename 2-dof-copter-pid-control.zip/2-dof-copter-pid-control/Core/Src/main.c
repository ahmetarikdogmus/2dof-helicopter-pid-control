/* USER CODE BEGIN Header */
/**
 * @file main.c
 * @brief STM32F072RB 2-DOF helicopter scheduling and UART telemetry.
 */
/* USER CODE END Header */
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "helicopter_control.h"
#include "esc_control.h"
#include <stdio.h>
/* USER CODE END Includes */

void SystemClock_Config(void);
void Error_Handler(void);

/* USER CODE BEGIN PD */
#define CTRL_PERIOD_MS          20u
#define PRINT_MS                100u
#define START_DELAY_MS          3000u

/* USER CODE END PD */

/* USER CODE BEGIN PV */
static uint32_t last_ctrl = 0;
static uint32_t last_print = 0;
static volatile uint16_t adc_yaw = 0;
static volatile uint16_t adc_pitch = 0;
static uint32_t boot_ms = 0;
static HelicopterControl control;
static EscControl esc;
/* USER CODE END PV */

/* USER CODE BEGIN PFP */
int fputc(int ch, FILE *f);
static HAL_StatusTypeDef ADC_Read2_CH0_CH1(uint16_t *ch0, uint16_t *ch1,
                                         uint32_t timeout_ms);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
int fputc(int ch, FILE *f)
{
  uint8_t c = (uint8_t)ch;
  HAL_UART_Transmit(&huart2, &c, 1, HAL_MAX_DELAY);
  (void)f;
  return ch;
}

static HAL_StatusTypeDef ADC_Read2_CH0_CH1(uint16_t *ch0, uint16_t *ch1, uint32_t timeout_ms)
{
  if (HAL_ADC_Start(&hadc) != HAL_OK) return HAL_ERROR;

  if (HAL_ADC_PollForConversion(&hadc, timeout_ms) != HAL_OK) { HAL_ADC_Stop(&hadc); return HAL_ERROR; }
  *ch0 = (uint16_t)HAL_ADC_GetValue(&hadc);

  if (HAL_ADC_PollForConversion(&hadc, timeout_ms) != HAL_OK) { HAL_ADC_Stop(&hadc); return HAL_ERROR; }
  *ch1 = (uint16_t)HAL_ADC_GetValue(&hadc);

  (void)HAL_ADC_Stop(&hadc);
  return HAL_OK;
}
#if defined(__GNUC__) && !defined(__ARMCC_VERSION)
/* Newlib uses __io_putchar; retain the existing per-character UART path. */
int __io_putchar(int ch)
{
  return fputc(ch, stdout);
}
#endif
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();

  /* USER CODE BEGIN 2 */
  (void)HAL_ADCEx_Calibration_Start(&hadc);
  EscControl_Init(&esc);
  HelicopterControl_Init(&control);
  boot_ms = HAL_GetTick();
  last_ctrl = HAL_GetTick();
  last_print = HAL_GetTick();
  printf("BOOT: NO CALIB | wait %ums then control | softstart %ums | yaw_neutral=%u\r\n",
         (unsigned)START_DELAY_MS, (unsigned)SOFTSTART_MS, (unsigned)esc.yaw_neutral_us);
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
    uint32_t now = HAL_GetTick();
    uint16_t ch0 = 0, ch1 = 0;
    /* CH0 yaw then CH1 pitch; keep both previous samples on ADC failure. */
    if (ADC_Read2_CH0_CH1(&ch0, &ch1, 10) == HAL_OK) {
      adc_yaw = ch0;
      adc_pitch = ch1;
    }
    if (!esc.control_enabled) {
      EscControl_HoldStartup(&esc);
      if ((now - boot_ms) >= START_DELAY_MS) {
        EscControl_Enable(&esc, now);
        HelicopterControl_Enable(&control, adc_yaw);
      }
      if ((now - last_print) >= PRINT_MS) {
        last_print += PRINT_MS;
        HelicopterControl_UpdateFeedback(&control, adc_yaw, adc_pitch);
        printf("%.2f,%.2f\r\n", (double)control.yaw_deg, (double)control.pitch_deg);
      }
      HAL_Delay(1);
      continue;
    }
    if ((now - last_ctrl) >= CTRL_PERIOD_MS) {
      /* Preserve accumulated deadlines, including startup catch-up. */
      last_ctrl += CTRL_PERIOD_MS;
      EscControlLimits limits = EscControl_GetLimits(&esc, now);
      HelicopterControl_UpdateFeedback(&control, adc_yaw, adc_pitch);
      HelicopterYawCommand yaw = HelicopterControl_UpdateYaw(&control, adc_yaw,
          now, limits.yaw_delta_min, limits.yaw_delta_max);
      if (yaw.update_pwm) {
        EscControl_ApplyYaw(&esc, yaw.delta_us, yaw.hard_neutral);
      }
      float pitch_target = HelicopterControl_UpdatePitch(&control, limits.pitch_max_us);
      EscControl_ApplyPitch(&esc, pitch_target);
      if ((now - last_print) >= PRINT_MS) {
        last_print += PRINT_MS;
        printf("%.2f,%.2f\r\n", (double)control.yaw_deg, (double)control.pitch_deg);
      }
    }
    HAL_Delay(1);
    /* USER CODE END 3 */
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) { Error_Handler(); }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}