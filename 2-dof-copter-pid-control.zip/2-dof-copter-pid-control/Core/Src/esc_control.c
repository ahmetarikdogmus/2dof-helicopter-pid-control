#include "esc_control.h"
#include "tim.h"

static float clamp_f(float x, float lo, float hi)
{
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static uint16_t clamp_u16(uint16_t x, uint16_t lo, uint16_t hi)
{
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static void TIM1_Set_1us_50Hz_Runtime(void)
{
  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);

  __HAL_TIM_SET_PRESCALER(&htim1, 47);
  __HAL_TIM_SET_AUTORELOAD(&htim1, 19999);
  __HAL_TIM_SET_COUNTER(&htim1, 0);
  htim1.Instance->EGR = TIM_EGR_UG;

  TIM1->BDTR |= TIM_BDTR_MOE;
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
}

static void TIM3_Set_1us_50Hz_Runtime(void)
{
  HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);

  __HAL_TIM_SET_PRESCALER(&htim3, 47);
  __HAL_TIM_SET_AUTORELOAD(&htim3, 19999);
  __HAL_TIM_SET_COUNTER(&htim3, 0);
  htim3.Instance->EGR = TIM_EGR_UG;

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
}

static void pitch_esc_set_us(uint16_t us)
{
  us = clamp_u16(us, ESC_MIN_US, ESC_MAX_US);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, us);
}

static void yaw_esc_set_us(uint16_t us)
{
  us = clamp_u16(us, ESC_MIN_US, ESC_MAX_US);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, us);
}

static uint16_t slew_u16(uint16_t cur, uint16_t target, uint16_t step)
{
  if (cur < target) {
    uint16_t d = (uint16_t)(target - cur);
    return (d > step) ? (uint16_t)(cur + step) : target;
  } else if (cur > target) {
    uint16_t d = (uint16_t)(cur - target);
    return (d > step) ? (uint16_t)(cur - step) : target;
  }
  return cur;
}

static uint16_t slew_asym_u16(uint16_t cur, uint16_t target, uint16_t up_step, uint16_t down_step)
{
  if (cur < target) {
    uint16_t d = (uint16_t)(target - cur);
    return (d > up_step) ? (uint16_t)(cur + up_step) : target;
  } else if (cur > target) {
    uint16_t d = (uint16_t)(cur - target);
    return (d > down_step) ? (uint16_t)(cur - down_step) : target;
  }
  return cur;
}

static uint16_t yaw_apply_neutral_deadband(const EscControl *esc, uint16_t us)
{
  uint16_t n = esc->yaw_neutral_us;

  if (us > n && us < (uint16_t)(n + YAW_PWM_DEADZONE_US)) {
    return (uint16_t)(n + YAW_PWM_DEADZONE_US + 1u);
  }

  if (us < n && us > (uint16_t)(n - YAW_PWM_DEADZONE_US)) {
    return (uint16_t)(n - YAW_PWM_DEADZONE_US - 1u);
  }

  return us;
}

void EscControl_HoldStartup(EscControl *esc)
{
  esc->pitch_out_us = ESC_MIN_US;
  esc->yaw_out_us = esc->yaw_neutral_us;
  pitch_esc_set_us(esc->pitch_out_us);
  yaw_esc_set_us(esc->yaw_out_us);
}

void EscControl_Init(EscControl *esc)
{
  *esc = (EscControl){0};
  esc->yaw_neutral_us = YAW_NEUTRAL_US_INIT;
  TIM1_Set_1us_50Hz_Runtime();
  TIM3_Set_1us_50Hz_Runtime();
  EscControl_HoldStartup(esc);
}

void EscControl_Enable(EscControl *esc, uint32_t now_ms)
{
  esc->control_enabled = 1u;
  esc->control_enable_ms = now_ms;
  esc->pitch_out_us = PITCH_CTRL_MIN_US;
  esc->yaw_out_us = esc->yaw_neutral_us;
}

EscControlLimits EscControl_GetLimits(const EscControl *esc, uint32_t now_ms)
{
  float k = 0.0f;
  if (esc->control_enabled) {
    uint32_t dt = now_ms - esc->control_enable_ms;
    k = (dt >= SOFTSTART_MS) ? 1.0f : (float)dt / (float)SOFTSTART_MS;
  }
  float yaw_delta_min_full = (float)YAW_REV_MAX_US - (float)esc->yaw_neutral_us;
  float yaw_delta_max_full = (float)YAW_FWD_MAX_US - (float)esc->yaw_neutral_us;
  EscControlLimits limits;
  limits.yaw_delta_min = yaw_delta_min_full * k;
  limits.yaw_delta_max = yaw_delta_max_full * k;
  limits.pitch_max_us = (float)PITCH_CTRL_MIN_US + k *
      ((float)PITCH_CTRL_MAX_US - (float)PITCH_CTRL_MIN_US);
  return limits;
}

void EscControl_ApplyPitch(EscControl *esc, float target_us)
{
  uint16_t target = (uint16_t)(target_us + 0.5f);
  esc->pitch_out_us = slew_u16(esc->pitch_out_us, target, PITCH_SLEW_US_STEP);
  esc->pitch_out_us = clamp_u16(esc->pitch_out_us, ESC_MIN_US, ESC_MAX_US);
  pitch_esc_set_us(esc->pitch_out_us);
}

void EscControl_ApplyYaw(EscControl *esc, float delta_us, uint8_t hard_neutral)
{
  if (hard_neutral) {
    esc->yaw_out_us = esc->yaw_neutral_us;
    yaw_esc_set_us(esc->yaw_out_us);
    return;
  }
  float yaw_u = (float)esc->yaw_neutral_us + delta_us;
  yaw_u = clamp_f(yaw_u, (float)YAW_REV_MAX_US, (float)YAW_FWD_MAX_US);
  uint16_t target = (uint16_t)(yaw_u + 0.5f);
  target = yaw_apply_neutral_deadband(esc, target);
  esc->yaw_out_us = slew_asym_u16(esc->yaw_out_us, target,
                                 YAW_SLEW_UP_US, YAW_SLEW_DOWN_US);
  esc->yaw_out_us = clamp_u16(esc->yaw_out_us, ESC_MIN_US, ESC_MAX_US);
  yaw_esc_set_us(esc->yaw_out_us);
}
