#ifndef HELICOPTER_CONTROL_H
#define HELICOPTER_CONTROL_H
#include <stdint.h>

/* Preserved angle-domain pitch PI and count-domain yaw PID parameters. */
#define DT_S                    (0.020f)

/* Yaw feedback and controller gains (ADC counts, microseconds). */
#define YAW_POT_LOW_ADC         950
#define YAW_POT_MID_ADC         2300
#define YAW_POT_HIGH_ADC        3700
#define YAW_MAX_DEG             90.0f
#define YAW_ADC_DB_COUNTS       6
#define YAW_CONTROL_SIGN        (+1.0f)
#define YAW_KP_US_PER_COUNT     0.13f
#define YAW_KI_US_PER_COUNT_S   0.100f
#define YAW_KD_US_S_PER_COUNT   0.000f

/* Integral scheduling and legacy freeze. */
#define YAW_I_ENABLE_COUNTS       150
#define YAW_I_LIMIT_NEAR_US       350.0f
#define YAW_I_LIMIT_FAR_US        40.0f
#define YAW_KI_NEAR_MULT          1.0f
#define YAW_KI_FAR_MULT           0.20f
#define YAW_I_LEAK_CENTER         0.995f /* Retained; unused in original flow. */
#define YAW_I_LEAK_FAR            0.96f

/* Minimum drive and preserved kick parameters. */
#define YAW_MIN_DELTA_US          65.0f
#define YAW_MIN_DELTA_ERR_CNT     12
#define YAW_KICK_AE_COUNTS        12
#define YAW_KICK_MS               30u
#define YAW_KICK_MIN_DELTA_US     70.0f
#define YAW_I_CUT_DEG   2.0f /* Retained; unused in original flow. */
#define YAW_I_FREEZE_COUNTS   25

/* Pitch piecewise feedback mapping and PI parameters. */
#define PITCH_ADC_LOW_RAW       1380u
#define PITCH_ADC_CENTER_RAW    2210u
#define PITCH_ADC_HIGH_RAW      3170u
#define PITCH_MAX_DEG           60.0f
#define PITCH_HOVER_US_INIT       1270u
#define PITCH_P_GAIN_US_PER_DEG   3.3f
#define PITCH_I_GAIN_US_PER_DEG_S 0.35f
#define PITCH_I_LIMIT_US          25.0f
#define PITCH_DEADBAND_DEG        0.6f
#define PITCH_CONTROL_SIGN        (+1.0f)

/* Application-owned state; this interface has no HAL dependency. */
typedef struct {
  float pitch_i_us;
  float yaw_i_us;
  int32_t yaw_prev_err;
  int32_t yaw_mid_adc;
  uint32_t yaw_kick_until;
  float pitch_deg;
  float yaw_deg;
} HelicopterControl;

typedef struct {
  float delta_us;
  uint8_t update_pwm;
  uint8_t hard_neutral;
} HelicopterYawCommand;

void HelicopterControl_Init(HelicopterControl *control);
void HelicopterControl_Enable(HelicopterControl *control, uint16_t yaw_adc);
void HelicopterControl_UpdateFeedback(HelicopterControl *control,
                                     uint16_t yaw_adc, uint16_t pitch_adc);
HelicopterYawCommand HelicopterControl_UpdateYaw(HelicopterControl *control,
    uint16_t yaw_adc, uint32_t now_ms, float delta_min_us, float delta_max_us);
float HelicopterControl_UpdatePitch(HelicopterControl *control, float max_us);
#endif /* HELICOPTER_CONTROL_H */
