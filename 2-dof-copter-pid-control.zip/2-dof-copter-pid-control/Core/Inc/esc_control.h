#ifndef ESC_CONTROL_H
#define ESC_CONTROL_H
#include <stdint.h>

/* Physical PWM limits, ramp duration and per-update slew steps. */
#define ESC_MIN_US              1000u
#define ESC_MAX_US              2000u
#define ESC_NEUTRAL_US          1500u /* Nominal only; applied yaw neutral is 1510. */
#define SOFTSTART_MS            1000u

/* Bidirectional yaw ESC. */
#define YAW_FWD_MAX_US          1750u
#define YAW_REV_MAX_US          1250u
#define YAW_PWM_DEADZONE_US     30u
#define YAW_SLEW_UP_US          15u
#define YAW_SLEW_DOWN_US        25u
#define YAW_NEUTRAL_US_INIT        1510u

/* Unidirectional pitch ESC. */
#define PITCH_CTRL_MIN_US       1100u
#define PITCH_CTRL_MAX_US       1450u
#define PITCH_SLEW_US_STEP      10u

typedef struct {
  uint16_t pitch_out_us;
  uint16_t yaw_out_us;
  uint16_t yaw_neutral_us;
  uint32_t control_enable_ms;
  uint8_t control_enabled;
} EscControl;

typedef struct {
  float yaw_delta_min;
  float yaw_delta_max;
  float pitch_max_us;
} EscControlLimits;

void EscControl_Init(EscControl *esc);
void EscControl_HoldStartup(EscControl *esc);
/* Seeds software history; PWM writes remain on the next update. */
void EscControl_Enable(EscControl *esc, uint32_t now_ms);
EscControlLimits EscControl_GetLimits(const EscControl *esc, uint32_t now_ms);
void EscControl_ApplyPitch(EscControl *esc, float target_us);
void EscControl_ApplyYaw(EscControl *esc, float delta_us, uint8_t hard_neutral);
#endif /* ESC_CONTROL_H */
